package com.cg.miniproject.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBConnection {
	static Connection connection=null;
	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg302",
					"training302");

			
		} catch (Exception e) {
			throw new RuntimeException("Error connecting to the database");
			
		}
		return connection;
	}
}
