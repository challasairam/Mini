package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.dao.HotelBookingDaoImpl;
import com.cg.miniproject.dao.IHotelBookingDao;

public class HotelBookingServiceImpl implements IHotelBookingService {

	@Override
	public boolean addHotels(Hotel hotel) {

		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addHotels(hotel);
	}

	@Override
	public boolean deleteHotel(String id) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.deleteHotel(id);

	}

	@Override
	public boolean addRooms(RoomDetails roomDetails) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addRooms(roomDetails);
	}

	@Override
	public boolean deleteRoom(String id) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.deleteRooms(id);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate d) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(d);
	}

}
