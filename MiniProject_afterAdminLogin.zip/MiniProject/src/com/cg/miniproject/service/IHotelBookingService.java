package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;

public interface IHotelBookingService {

	public boolean addHotels(Hotel hotel);

	public boolean deleteHotel(String id);

	public boolean addRooms(RoomDetails roomDetails);

	public boolean deleteRoom(String id);

	public ArrayList<BookingDetails> retrieveBookings(String hotelId);

	public ArrayList<BookingDetails> retrieveBookings(LocalDate d);

}
