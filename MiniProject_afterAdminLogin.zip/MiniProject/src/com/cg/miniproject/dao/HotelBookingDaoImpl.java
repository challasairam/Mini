package com.cg.miniproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.util.DBConnection;

public class HotelBookingDaoImpl implements IHotelBookingDao{
boolean result=false;
	@Override
	public boolean addHotels(Hotel hotel) {
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement("insert into hotel(hotel_id,hotel_name,address,description,city,avg_rate_per_night) values (?,?,?,?,?,?)");
			preparedStatement.setString(1,hotel.getHotelId());
			preparedStatement.setString(2, hotel.getHotelName());
			preparedStatement.setString(3, hotel.getAddress());
			preparedStatement.setString(4, hotel.getDescription());
			preparedStatement.setString(5, hotel.getCity());
			preparedStatement.setDouble(6, hotel.getAvgRatePerNight());
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	@Override
	public boolean deleteHotel(String id) {
		Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement("delete from hotel where hotel_id=?");
			preparedStatement.setString(1, id);
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public boolean addRooms(RoomDetails roomDetails) {
		try {
			System.out.println(roomDetails.getRoomType());
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement("insert into roomdetails values (?,?,?,?,?,?)");
			preparedStatement.setString(1,roomDetails.getHotelId());
			preparedStatement.setString(2, roomDetails.getRoomId());
			preparedStatement.setString(3, roomDetails.getRoomNo());
			preparedStatement.setString(4, roomDetails.getRoomType());
			preparedStatement.setDouble(5, roomDetails.getPerNightRate());
			preparedStatement.setString(6, roomDetails.getAvailability());
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	@Override
	public boolean deleteRooms(String id) {
	Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement("delete from roomdetails where room_id=?");
			preparedStatement.setString(1, id);
			int rows_updated=preparedStatement.executeUpdate();
			if(rows_updated>0)
				result=true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId) {
		ArrayList<BookingDetails> list=new ArrayList<BookingDetails>();
	Connection connection=DBConnection.getConnection();
		
		try {
			PreparedStatement preparedStatement=connection.prepareStatement("select b.* from bookingdetails b join roomdetails r on b.room_id=r.room_id join hotel h on h.hotel_id=r.hotel_id where h.hotel_id=?");
			preparedStatement.setString(1, hotelId);
			preparedStatement.executeQuery();
			ResultSet resultSet=preparedStatement.getResultSet();
			if(!resultSet.isBeforeFirst())
				System.err.println("No data found with given hotel id");
			while(resultSet.next())
			{
				/*System.out.println("In loop");*/
				BookingDetails details=new BookingDetails();
				details.setBookingId(resultSet.getString(1));
				details.setRoomId(resultSet.getString(2));
				details.setUserId(resultSet.getString(3));
				details.setBookedFrom(resultSet.getString(4));
				details.setBookedTo(resultSet.getString(5));
				details.setNoOfAdults(resultSet.getInt(6));
				details.setNoOfChildren(resultSet.getInt(7));
				details.setAmount(resultSet.getDouble(8));
				list.add(details);
			}
			}
		
		catch(Exception e)
		{
			
		}
		return list;
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate d) {
		/*System.out.println(d.toString());*/
		/*java.sql.Date d1=new Date(d.getTime());*/
		//System.out.println(d1);
		
		ArrayList<BookingDetails> list=new ArrayList<BookingDetails>();
		Connection connection=DBConnection.getConnection();
			
			try {
				PreparedStatement preparedStatement=connection.prepareStatement("select * from bookingdetails where booked_from>=? and booked_to<=?");
				System.out.println(Date.valueOf(d));
				preparedStatement.setDate(1, Date.valueOf(d));
				preparedStatement.setDate(2, Date.valueOf(d));
				preparedStatement.executeQuery();
				ResultSet resultSet=preparedStatement.getResultSet();
				if(!resultSet.isBeforeFirst())
					System.err.println("No data found with given hotel id");
				while(resultSet.next())
				{
					BookingDetails details=new BookingDetails();
					details.setBookingId(resultSet.getString(1));
					details.setRoomId(resultSet.getString(2));
					details.setUserId(resultSet.getString(3));
					details.setBookedFrom(resultSet.getString(4));
					details.setBookedTo(resultSet.getString(5));
					details.setNoOfAdults(resultSet.getInt(6));
					details.setNoOfChildren(resultSet.getInt(7));
					details.setAmount(resultSet.getDouble(8));
					list.add(details);
				}
				}
			
			catch(Exception e)
			{
				
			}
			return list;
		
		
	}
}
