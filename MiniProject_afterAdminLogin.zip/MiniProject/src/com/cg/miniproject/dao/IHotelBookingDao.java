package com.cg.miniproject.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;

public interface IHotelBookingDao {
	public boolean addHotels(Hotel hotel);

	public boolean deleteHotel(String id);

	public boolean addRooms(RoomDetails roomDetails);

	public boolean deleteRooms(String id);

	public ArrayList<BookingDetails> retrieveBookings(String hotelId);

	public ArrayList<BookingDetails> retrieveBookings(LocalDate d);
}
