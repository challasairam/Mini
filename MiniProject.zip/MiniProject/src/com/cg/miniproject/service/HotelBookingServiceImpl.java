package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.dao.HotelBookingDaoImpl;
import com.cg.miniproject.dao.IHotelBookingDao;

public class HotelBookingServiceImpl implements IHotelBookingService {
	IHotelBookingDao dao = new HotelBookingDaoImpl();
	public ArrayList<Hotel> getHotelList() {
		return dao.getHotelList();
	}
	public ArrayList<RoomDetails> getRoomDetails(String id) {
		return dao.getRoomDetails(id);
	}
	@Override
	public void insertBookingDetails(String roomId, LocalDate sDate,
			LocalDate eDate, Integer a, Integer c) {
		// TODO Auto-generated method stub
		dao.insertBookingDetails(roomId, sDate, eDate, a, c);
	}
}
