package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;

public interface IHotelBookingService {

	public ArrayList<Hotel> getHotelList();

	public ArrayList<RoomDetails> getRoomDetails(String id);

	public void insertBookingDetails(String roomId, LocalDate sDate, LocalDate eDate,
			Integer a, Integer c);

}
