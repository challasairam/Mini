package com.cg.miniproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.util.DBConnection;

public class HotelBookingDaoImpl implements IHotelBookingDao {
	public ArrayList<Hotel> getHotelList() {
		ArrayList<Hotel> list = new ArrayList<Hotel>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement("select city,hotel_name,hotel_id from Hotel");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Hotel hotel = new Hotel();
				hotel.setCity(resultSet.getString(1));
				hotel.setHotelName(resultSet.getString(2));
				hotel.setHotelId(resultSet.getString(3));
				list.add(hotel);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<RoomDetails> getRoomDetails(String id) {
		// TODO Auto-generated method stub
		ArrayList<RoomDetails> details = new ArrayList<RoomDetails>();
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement("select hotel_id,room_id,room_no,room_type,per_night_rate,availability from RoomDetails where hotel_id = ? and availability='A'");
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				RoomDetails roomDetails = new RoomDetails();
				roomDetails.setHotelId(resultSet.getString(1));
				roomDetails.setRoomId(resultSet.getString(2));
				roomDetails.setRoomNo(resultSet.getString(3));
				roomDetails.setRoomType(resultSet.getString(4));
				roomDetails.setPerNightRate(resultSet.getDouble(5));
				roomDetails.setAvailability(resultSet.getString(6));
				details.add(roomDetails);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return details;
	}

	@Override
	public void insertBookingDetails(String roomId, LocalDate sDate,
			LocalDate eDate, Integer a, Integer c) {
		// TODO Auto-generated method stub
		Period period = Period.between(sDate, eDate);
		Integer diff = period.getDays();
		User user = new User();
		//System.out.println(diff + amount);
		Connection connection = DBConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		//int res = 0;
		try {
			PreparedStatement statement = connection.prepareStatement("select per_night_rate from RoomDetails where room_id=?");
			statement.setString(1, roomId);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
			RoomDetails details = new RoomDetails();
			details.setPerNightRate(resultSet.getDouble(1));
			Double amount = details.getPerNightRate() * diff;
			preparedStatement = connection
					.prepareStatement("insert into BookingDetails values(seq_booking.nextval,?,?,?,?,?,?,?)");
			preparedStatement.setString(1, roomId);
			preparedStatement.setString(2, user.getUserId());
			preparedStatement.setDate(3, Date.valueOf(sDate)); 
			preparedStatement.setDate(4,Date.valueOf(eDate));
			preparedStatement.setLong(5, a);
			preparedStatement.setLong(6, c);
			preparedStatement.setDouble(7, amount);
			int rowsUpdated=preparedStatement.executeUpdate();
			if(rowsUpdated>0)
			{
			PreparedStatement preparedStatement2=connection.prepareStatement("update roomdetails set availability='NA' where room_id=?");
			preparedStatement2.setString(1, roomId);
			preparedStatement2.executeUpdate();
			}
			}
			//System.out.println(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
