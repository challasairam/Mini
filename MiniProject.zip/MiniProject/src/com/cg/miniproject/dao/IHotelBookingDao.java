package com.cg.miniproject.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;

public interface IHotelBookingDao {
	public ArrayList<Hotel> getHotelList();

	public ArrayList<RoomDetails> getRoomDetails(String id);

	public void insertBookingDetails(String roomId, LocalDate sDate, LocalDate eDate,
			Integer a, Integer c);

}
