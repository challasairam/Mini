package com.cg.miniproject.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.service.HotelBookingServiceImpl;
import com.cg.miniproject.service.IHotelBookingService;

public class HotelBooking {
	public static void main(String[] args) {
		Hotel hotel = new Hotel();
		Scanner sc = new Scanner(System.in);
		IHotelBookingService service = new HotelBookingServiceImpl();
		System.out.println("List Of Hotels:");

		try {
			ArrayList<Hotel> list = new ArrayList<Hotel>();
			list = service.getHotelList();
			if (!list.isEmpty()) {
				int i = 1;
				for (Hotel hotel2 : list) {
					System.out.println(i + "." + hotel2.getHotelId() + "-"
							+ hotel2.getCity() + "-" + hotel2.getHotelName());
					i++;
				}
				System.out.println("Enter hotel Id:");
				String id = sc.next();
				ArrayList<RoomDetails> details = service.getRoomDetails(id);
				if (!details.isEmpty()) {
					for (RoomDetails roomDetails : details) {
						System.out.println(roomDetails.getHotelId() + "-"
								+ roomDetails.getRoomId() + "-"
								+ roomDetails.getRoomNo() + "-"
								+ roomDetails.getRoomType() + "-"
								+ roomDetails.getPerNightRate() + "-"
								+ roomDetails.getAvailability());
					}
					System.out.println("Enter room id:");
					String roomId= sc.next();
					System.out.println("Enter Starting date:");
					String sDate= sc.next();
					DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/d/yyyy");
				    LocalDate sdate = LocalDate.parse(sDate, dateFormat);
					System.out.println("Enter Ending date:");
					String eDate= sc.next();
				    LocalDate edate = LocalDate.parse(eDate, dateFormat);
					System.out.println("Enter no of adults:");
					Integer a = sc.nextInt();
					System.out.println("Enter no of children:");
					Integer c = sc.nextInt();
					service.insertBookingDetails(roomId,sdate,edate,a,c);
				} else {
					System.out.println("Rooms not available");
				}
			} else {
				System.out.println("No Hotels.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
