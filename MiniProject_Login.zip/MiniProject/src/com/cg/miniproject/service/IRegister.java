package com.cg.miniproject.service;

import com.cg.miniproject.bean.User;

public interface IRegister {
	public boolean register(User user);
	public  boolean login(User user);
}
