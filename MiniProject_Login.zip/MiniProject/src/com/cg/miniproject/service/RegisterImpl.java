package com.cg.miniproject.service;

import com.cg.miniproject.bean.User;
import com.cg.miniproject.dao.IRegDao;
import com.cg.miniproject.dao.RegDaoImpl;

public class RegisterImpl implements IRegister{
	
IRegDao dao = new RegDaoImpl();
public boolean register(User user) {
	
	//System.out.println("register");
	return dao.register(user);
}
public boolean login(User user) {
	
	//System.out.println("login");
	return dao.login(user);
}
}