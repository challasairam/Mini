package com.cg.miniproject.dao;

public class QueryMapper {
	public static final String USERID_QUERY_SEQUENCE = null;
	//public static final String INSERT_QUERY = null;
	public static String QUERY1="insert into Users values(userId_sequence.NEXTVAL,?,?,?,?,?,?,?)";
	//public static final String USERID_QUERY_SEQUENCE="SELECT userId_sequence.CURRVAL FROM DUAL";
	
	
}
