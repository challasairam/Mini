package com.cg.miniproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.cg.miniproject.bean.User;
import com.cg.miniproject.util.DBConnection;

public class RegDaoImpl implements IRegDao{
	boolean b;
	@Override
	public boolean register(User user) 
	{

		try {
			
			
			Connection conn = DBConnection.getConnection();	
			
			PreparedStatement preparedStatement=null;		
			//ResultSet resultSet;
			
			//String userId;
			
			int queryResult;
				
				preparedStatement=conn.prepareStatement(QueryMapper.QUERY1);

					
				preparedStatement.setString(1,user.getPassword());
				preparedStatement.setString(2,user.getRole());	
				preparedStatement.setString(3,user.getUserName());		
				preparedStatement.setString(4,user.getMobileNo());			
				preparedStatement.setString(5,user.getPhone());
				preparedStatement.setString(6,user.getAddress());			
				preparedStatement.setString(7,user.getEmail());			
				
				queryResult=preparedStatement.executeUpdate();
			if(queryResult>0)
				b=true;
				//preparedStatement = conn.prepareStatement(QueryMapper.USERID_QUERY_SEQUENCE);
				//resultSet=preparedStatement.executeQuery();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}
	public boolean login(User user) 
	{

		try {
			
			
			Connection conn = DBConnection.getConnection();	
			PreparedStatement ps = conn.prepareStatement("SELECT USER_NAME,PASSWORD from Users where USER_NAME=? AND PASSWORD=? AND Role=?");
			 ps.setString(1,user.getUserName());
			 ps.setString(2,user.getPassword());
			 ps.setString(3, user.getRole());
			 
			 ResultSet resultSet= ps.executeQuery();
			if(!resultSet.isBeforeFirst())
			{
				System.out.println("Login Failed");
			}
			else
				b=true;
					// TODO Auto-generated method stub
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}
	
}
