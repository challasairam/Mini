package com.cg.miniproject.dao;

import com.cg.miniproject.bean.User;

public interface IRegDao {

public boolean login(User user);

public boolean register(User user);

}
