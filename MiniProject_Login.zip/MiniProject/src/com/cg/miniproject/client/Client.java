package com.cg.miniproject.client;

import java.util.Scanner;

import com.cg.miniproject.bean.User;
import com.cg.miniproject.service.IRegister;
import com.cg.miniproject.service.RegisterImpl;

public class Client {

	public static void main(String[] args) {
		// String userName;
		// String password;
		// String mobileNo;
		// String phone;
		// String address;
		// String email;
		User user = new User();
		IRegister ireg= new RegisterImpl();
		boolean result=false;;
		Scanner sc = new Scanner(System.in);

		System.out.println("Choose your category :\n");
		System.out.println("1.User" + "2.Employee" + "3.Admin");
		int choice=sc.nextInt();
		if(choice==1)
		{
			user.setRole("User");
			
//		}else if(choice==2)
//		{
//			user.setRole("Employee");
//			
//		}
//		else if(choice==3)
//		{
//			user.setRole("Admin");
//			
//		}
		
		System.out.println("You want to Register or Login?");
		System.out.println("1.Register" + "2.Login");
		int choice2 = sc.nextInt();
		switch(choice2){
		case 1:User user2=new User();
		      user2.setRole(user.getRole());
			System.out.println("Enter Username :");
			user2.setUserName(sc.next());
			System.out.println("Enter Password :");
			user2.setPassword(sc.next());
			System.out.println("Enter MobileNo :");
			user2.setMobileNo(sc.next());
			System.out.println("Enter Phone :");
			user2.setPhone(sc.next());
			System.out.println("Enter Address :");
			user2.setAddress(sc.next());
			System.out.println("Enter Email :");
			user2.setEmail(sc.next());
			result=ireg.register(user2);
			if(result)
			{
				
			System.out.println("Registration successfull !!!");
			}
			else{
				System.out.println("Registration Failed !!!");
			}
			break;

		case 2:
			System.out.println("Enter Username :");
			user.setUserName(sc.next());
			System.out.println("Enter Password :");
			user.setPassword(sc.next());
			result=ireg.login(user);
			if(result)
			{
				
			System.out.println("Login Successfull !!!");
			}
			else{
				System.out.println("Login Failed !!!Please Login Again");
			}
			break;
		default: System.out.println("Invalid option");
		}
		}
		else if(choice==2)
			{
				user.setRole("Employee");
				System.out.println("You want to Register or Login?");
				System.out.println("1.Register" + "2.Login");
				int choice2 = sc.nextInt();
				switch(choice2){
				case 1:User user2=new User();
				      user2.setRole(user.getRole());
					System.out.println("Enter Username :");
					user2.setUserName(sc.next());
					System.out.println("Enter Password :");
					user2.setPassword(sc.next());
					System.out.println("Enter MobileNo :");
					user2.setMobileNo(sc.next());
					System.out.println("Enter Phone :");
					user2.setPhone(sc.next());
					System.out.println("Enter Address :");
					user2.setAddress(sc.next());
					System.out.println("Enter Email :");
					user2.setEmail(sc.next());
					result=ireg.register(user2);
					if(result)
					{
						
					System.out.println("Registration successfull !!!");
					}
					else{
						System.out.println("Registration Failed !!!");
					}
					break;

				case 2:
					System.out.println("Enter Username :");
					user.setUserName(sc.next());
					System.out.println("Enter Password :");
					user.setPassword(sc.next());
					result=ireg.login(user);
					if(result)
					{
						
					System.out.println("Login Successfull !!!");
					}
					else{
						System.out.println("Login Failed !!!Please Login Again");
					}
					break;
				default: System.out.println("Invalid option");
				}
				
			}else if(choice==3)
				{
				user.setRole("Admin");
				System.out.println("Enter Username :");
				user.setUserName(sc.next());
				System.out.println("Enter Password :");
				user.setPassword(sc.next());
				result=ireg.login(user);
				if(result)
				{
					
				System.out.println("Login Successfull !!!");
				}
				else{
					System.out.println("Login Failed !!!Please Login Again");
				}
			}

	}
}
