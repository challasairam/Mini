package com.capgemini.exception;

public class BookingException extends Exception{
String error;

public BookingException(String error) {
	super();
	this.error = error;
}

}
