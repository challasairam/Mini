package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.TrainServiceImpl;

public class MainClient {

	public static void main(String[] args) {
		BookingBean bookingBean=new BookingBean();
		ArrayList<TrainBean> list=new ArrayList<TrainBean>();
		TrainServiceImpl ts=new TrainServiceImpl();
		int choice=-1,booking_id;
		while(choice!=2)
		{
			System.out.println("Please select any one of the option below");
			System.out.println("\n1.Book Ticket\n2.Exit");
			Scanner scanner=new Scanner(System.in);
			choice=scanner.nextInt();
			if(choice==1)
			{
				list=ts.retrieveTrainDetails();
			
				System.out.println(list.get(0)+"\n"+list.get(1)+"\n"+list.get(2)+"\n"+list.get(3));
				//System.out.println(list);
				try {
					Matcher m;
					do
					{
					
					System.out.println("Please enter Customer id");
					Scanner scanner1=new Scanner(System.in);
					String cid=scanner1.nextLine();
					Pattern pattern=Pattern.compile("^[A-Z][0-9]{6}$");
					m=pattern.matcher(cid);
					if(!m.find())
						System.err.println("Customer id should start with capital letter followed by 6 digits");
					else
					{
						bookingBean.setCustid(cid);
						booking_id=ts.bookTicket(bookingBean);
						System.out.println("Thank You.Your booking id is "+booking_id);
						break;
						
					}
						
					}while(!m.find());
					
				} catch (BookingException e) {
					
					e.printStackTrace();
				}
				
				
			}
			else if(choice==2){
				System.exit(0);
			}
		}

	}

}
