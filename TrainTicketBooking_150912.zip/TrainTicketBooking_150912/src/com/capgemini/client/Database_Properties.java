package com.capgemini.client;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
public class Database_Properties {
	public static void main(String[] args) {
		
		
		Properties tempProp = new Properties();
		/* Database connection parameter properties are set */
		tempProp.setProperty("url",
				"jdbc:oracle:thin:@10.219.34.3:1521/orcl");
		tempProp.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		tempProp.setProperty("username", "trg310");
		tempProp.setProperty("password", "training310");	
		FileOutputStream propsFile;
	

		try {
			propsFile = new FileOutputStream("resources/Database.properties");
			tempProp.store(propsFile, "Properties File to the Database Connection");
			propsFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}
	}

}
