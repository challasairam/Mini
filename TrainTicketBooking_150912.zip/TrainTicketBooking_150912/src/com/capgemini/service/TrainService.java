package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;

import com.capgemini.exception.BookingException;

public interface TrainService {
ArrayList<TrainBean> retrieveTrainDetails();
int bookTicket(BookingBean bookingBean) throws BookingException;
}
