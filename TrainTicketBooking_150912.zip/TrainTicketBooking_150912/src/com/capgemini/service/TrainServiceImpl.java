package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.BookingException;

public class TrainServiceImpl implements TrainService {
	BookingBean bookingBean=new BookingBean();
	TrainDaoImpl tdao=new TrainDaoImpl();
	ArrayList<TrainBean> list=new ArrayList<TrainBean>();
	int booking_id;
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() {
		
		list=tdao.retrieveTrainDetails();
		//System.out.println(list);
		return list;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		booking_id=tdao.bookTicket(bookingBean);
		return booking_id;
	}

}
