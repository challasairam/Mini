package com.capgemini.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.TrainBean;
import com.capgemini.service.TrainService;
import com.capgemini.service.TrainServiceImpl;

public class TrainDaoImplTest {

	@Before
	public void setUp() throws Exception {
		System.out.println("Started Execution");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Ended Execution");
	}

	@Test
	public void testTrainId() {
		TrainBean t=new TrainBean();
		t.setTrainid(1);
		assertEquals(1,t.getTrainid());

	}
	@Test
	public void testTrainFare() {
		TrainBean t=new TrainBean();
		t.setFare(200);
		assertEquals(200,t.getFare());
	}
	@Test
	public void testTrainFromstop() {
		TrainBean t=new TrainBean();
		t.setFromStop("Mumbai");
		assertEquals("Mumbai",t.getFromStop());
	}
	@Test
	public void testTrainTostop() {
		TrainBean t=new TrainBean();
		t.setToStop("Chennai");
		assertEquals("Chennai",t.getToStop());
	}
	
}
