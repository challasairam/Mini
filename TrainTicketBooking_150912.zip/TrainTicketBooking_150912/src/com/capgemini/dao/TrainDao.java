package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;

public interface TrainDao {
ArrayList<TrainBean> retrieveTrainDetails();
int bookTicket(BookingBean bookingBean) throws BookingException;
}
