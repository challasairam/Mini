package com.capgemini.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Logger;
import java.util.regex.Matcher;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;

public class TrainDaoImpl implements TrainDao {
	Properties props=new Properties();
	BookingBean bookingBean=new BookingBean();
	TrainBean trainBean=new TrainBean();
	ArrayList<TrainBean> list=new ArrayList<TrainBean>();
	ArrayList alist=new ArrayList();
	int booking_id,train_id,seats;
	String url,username,password;
	Connection conn;
	Statement statement;
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() {
		
		
		
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		try(FileInputStream in = new FileInputStream("resources/Database.properties"))
		{
			props.load(in);
			in.close();
			String driver = props.getProperty("driver");
			if (driver != null) {
			    Class.forName(driver) ;
			}

			url = props.getProperty("url");
			username = props.getProperty("username");
			password = props.getProperty("password");

			conn = DriverManager.getConnection(url, username, password);
			statement=conn.createStatement();
			ResultSet rs=statement.executeQuery("SELECT * FROM TrainDetails");
			while(rs.next())
			{
	
				alist.add(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getInt(5)+" "+rs.getInt(6)+" "+rs.getString(7)+"\n");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	
		return alist;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger myLogger =  Logger.getLogger(TrainDaoImpl.class.getName());
	
		try(FileInputStream in = new FileInputStream("resources/Database.properties"))
		{
			props.load(in);
			in.close();
			String driver = props.getProperty("driver");
			if (driver != null) {
			    Class.forName(driver) ;
			}

			url = props.getProperty("url");
			username = props.getProperty("username");
			password = props.getProperty("password");

			conn = DriverManager.getConnection(url, username, password);
			statement=conn.createStatement();
		
			
			int count;
			do
			{
				count=0;
				System.out.println("Please enter Train ID");
				Scanner scanner=new Scanner(System.in);
				train_id=scanner.nextInt();
				ResultSet resultset=statement.executeQuery("select * from TrainDetails");
			while(resultset.next())
			{
				if(train_id==resultset.getInt("trainId"))
				{
					
					++count;
				}		
			}
			if(count==0){
				System.err.println("Train ID does not exists. Please enter correct train id");
			}
			else
			{   bookingBean.setTrainid(train_id);
				do
				{
					count=0;
					System.out.println("Please enter no of seats to be booked");
					Scanner scanner1=new Scanner(System.in);
					seats=scanner1.nextInt();
					PreparedStatement pst=conn.prepareStatement("select availableSeats from TrainDetails where trainId=?");
					pst.setInt(1, train_id);
					pst.executeUpdate();
					ResultSet resultset1=pst.getResultSet();
				while(resultset1.next())
				{
					if(seats>0 && resultset1.getInt("availableSeats")>seats)
					{
						
						++count;
					}		
				}
				if(count==0){
					System.err.println("Sorry No Seats are available. Please select lesser no of seats");
				}
				else
				{
					bookingBean.setNoOfSeat(seats);
				break;
				}
				}while(count==0);
			}
				
			}while(count==0);
			
			int c=0;
			ResultSet rs=statement.executeQuery("SELECT table_name FROM user_tables");
			while(rs.next())
			{
				if(rs.getString("table_name").equals("BOOKINGDETAILS"))
				{
					++c;

				}
					
			}
			if(c==0)
			{
				statement.execute("CREATE TABLE BookingDetails(bookingId NUMBER PRIMARY KEY,custId VARCHAR2(10),noOfSeats NUMBER,trainId REFERENCES TrainDetails(trainId) ON DELETE CASCADE)");
				statement.execute("DROP SEQUENCE Booking_id_seq");
				statement.execute("CREATE SEQUENCE Booking_id_seq INCREMENT BY 1 START WITH 1001 MAXVALUE 9999 NOCYCLE");
				c=1;
			}
			if(c==1)
			{
			PreparedStatement pst=conn.prepareStatement("INSERT INTO BookingDetails VALUES (Booking_id_seq.NEXTVAL,?,?,?)");
			pst.setString(1, bookingBean.getCustid());
			pst.setInt(2,bookingBean.getNoOfSeat());
			pst.setInt(3,bookingBean.getTrainid());
			pst.executeUpdate();
			PreparedStatement pst1=conn.prepareStatement("UPDATE TrainDetails SET availableSeats=availableSeats-? WHERE trainId=?");
			pst1.setInt(1,bookingBean.getNoOfSeat());
			pst1.setInt(2, bookingBean.getTrainid());
			pst1.executeUpdate();
		    
			}
			PreparedStatement p=conn.prepareStatement("SELECT bookingId FROM BookingDetails WHERE custId=?");
			p.setString(1, bookingBean.getCustid());
			p.executeUpdate();
			ResultSet r=p.getResultSet();
			while(r.next())
			{
				bookingBean.setBookingid(r.getInt(1));
			}
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		myLogger.info("Booking is confirmed for "+bookingBean.getCustid()+" with booking id "+bookingBean.getBookingid());
		return bookingBean.getBookingid();
	}

}
